﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class DataPairBool
    {
        #region Properties
        private bool _value;
        private string _address;
        #endregion

        #region Interfaces
        public bool Value { get { return _value; } set { this._value = value; } }
        public string Address { get { return _address; } set { this._address = value; } }
        #endregion

        #region Constructors
        public DataPairBool()
        {
            this._value = false;
            this._address = string.Empty;
        }
        public DataPairBool(bool value, string adress)
        {
            this._value = value;
            this._address = adress;
        }
        #endregion
    }

    public class DataPairInt
    {
        #region Properties
        private int _value;
        private string _address;
        #endregion

        #region Interfaces
        public int Value { get { return _value; } set { this._value = value; } }
        public string Address { get { return _address; } set { this._address = value; } }
        public string ValueString { get { return this._value.ToString(); } }
        #endregion

        #region Constructors
        public DataPairInt()
        {
            this._value = 0;
            this._address = string.Empty;
        }
        public DataPairInt(int value, string adress)
        {
            this._value = value;
            this._address = adress;
        }
        #endregion
    }

    public class DataPairFloat
    {
        #region Properties
        private float _value;
        private string _address;
        #endregion

        #region Interfaces
        public float Value { get { return _value; } set { this._value = value; } }
        public string Address { get { return _address; } set { this._address = value; } }
        public string ValueString { get { return string.Format("{0:N6}", this._value); } }
        #endregion

        #region Constructors
        public DataPairFloat()
        {
            this._value = 0;
            this._address = string.Empty;
        }
        public DataPairFloat(float value, string adress)
        {
            this._value = value;
            this._address = adress;
        }
        #endregion
    }

    public class DataPairString
    {
        #region Properties
        private string _value;
        private string _address;
        #endregion

        #region Interfaces
        public string Value { get { return _value; } set { this._value = value; } }
        public string Address { get { return _address; } set { this._address = value; } }
        #endregion

        #region Constructors
        public DataPairString()
        {
            this._value = string.Empty;
            this._address = string.Empty;
        }
        public DataPairString(string value, string adress)
        {
            this._value = value;
            this._address = adress;
        }
        #endregion
    }

    public class DataPairDatetime
    {
        #region Properties
        private DateTime _value;
        private string _address;
        #endregion

        #region Interfaces
        public DateTime Value { get { return _value; } set { this._value = value; } }
        public string Address { get { return _address; } set { this._address = value; } }
        public string ValueString { get { return this._value.ToString("dd/MM/yyyy HH:mm:ss.fff"); } }
        #endregion

        #region Constructors
        public DataPairDatetime()
        {
            this._value = new DateTime();
            this._address = string.Empty;
        }
        public DataPairDatetime(DateTime value, string adress)
        {
            this._value = value;
            this._address = adress;
        }
        #endregion
    }
}
