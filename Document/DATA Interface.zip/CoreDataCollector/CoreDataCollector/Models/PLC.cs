﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Snap7;

namespace CoreDataCollector.Models
{
    public class PLC
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Properties
        private string _Name;
        private string _IP = "10.84.7.62";
        private int _Rack = 0;
        private int _Slot = 3;
        private S7Client _Client2PLC;

        private string[] _spliters = new string[] { "DB",".","X","D","W", "B"};
        #endregion

        #region Interfaces
        public string Name { get { return this._Name; } set { this._Name = value; } }
        public string IP { get { return this._IP; } set { this._IP = value; } }
        public int Rack { get { return this._Rack; } set { this._Rack = value; } }
        public int Slot { get { return this._Slot; } set { this._Slot = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of PLC Class
        /// </summary>
        /// <param name="IP">IP of the target PLC. Default value is 127.0.0.1</param>
        /// <param name="Rack">PLC Rack. Default value is 0</param>
        /// <param name="Slot">PLC Slot. Default value is 2</param>
        public PLC(string IP, int Rack, int Slot)
        {
            this._IP = IP;
            this._Rack = Rack;
            this._Slot = Slot;
            this._Client2PLC = new S7Client();
        }
        public PLC(string Name)
        {
            this._Name = Name;
            this._Client2PLC = new S7Client();
        }
        public PLC()
        {
            this._Client2PLC = new S7Client();
        }
        #endregion

        #region Methods
        public bool PLCConnect()
        {
            int res = _Client2PLC.ConnectTo(this._IP, this._Rack, this._Slot);
            if (res == 0)
            {
                //error = "PLC Connected";
                //level = LogLevel.DEBUG;
                log.Debug("PLC connected :" + this._Name + " IP: " + this._IP.ToString() + " Rack: " + this._Rack.ToString() + " Slot: " + this._Slot.ToString());
                return true;
            }
            else
            {
                //error = "Cannot connect to PLC. Check your PLC's IP or physical connection";
                //level = LogLevel.ERROR;
                log.Error("Cannot connect to PLC. Check your PLC's IP or physical connection :" + this._Name + " IP: " + this._IP.ToString() + " Rack: " + this._Rack.ToString() + " Slot: " + this._Slot.ToString());
                return false;
            }
        }

        public bool Connected()
        {
            return this._Client2PLC.Connected();
        }

        public bool ReadBit(string address)
        {
            byte[] buffer = new byte[1];
            bool result = false;
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if(adr.Count() < 3)
            {
                //Log here
                result = false;
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 1, buffer);
                result = S7.GetBitAt(buffer, 0, adr[2]);
            }
            return result;
            //this._Client2PLC.
        }

        public float ReadReal(string address)
        {
            byte[] buffer = new byte[4];
            float result = 0;
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if (adr.Count() < 2)
            {
                //Log here
                result = 0;
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 4, buffer);
                result = S7.GetRealAt(buffer,0);
            }
            return result;
        }

        public int ReadInteger(string address)
        {
            byte[] buffer = new byte[2];
            int result = 0;
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if (adr.Count() < 2)
            {
                //Log here
                result = 0;
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 2, buffer);
                result = S7.GetIntAt(buffer,0);
            }
            return result;
        }

        public int ReadDInteger(string address)
        {
            byte[] buffer = new byte[4];
            int result = 0;
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if (adr.Count() < 2)
            {
                result = 0;
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 4, buffer);
                result = S7.GetDIntAt(buffer, 0);
            }
            return result;
        }

        public string ReadString(string address)
        {
            byte[] buffer = new byte[30];
            string result = string.Empty;
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if (adr.Count() < 2)
            {
                //Log here
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 30, buffer);
                result = S7.GetStringAt(buffer,0);
            }
            return result;
        }

        public DateTime ReadDateTime(string address)
        {
            byte[] buffer = new byte[12];
            DateTime result = new DateTime();
            string[] stradr = address.Split(this._spliters, StringSplitOptions.RemoveEmptyEntries);
            int[] adr = Array.ConvertAll(stradr, int.Parse);
            if (adr.Count() < 2)
            {
                //Log here
            }
            else
            {
                this._Client2PLC.DBRead(adr[0], adr[1], 12, buffer);
                result = S7.GetDTLAt(buffer, 0);
            }
            return result;
        }
        #endregion
    }
}
