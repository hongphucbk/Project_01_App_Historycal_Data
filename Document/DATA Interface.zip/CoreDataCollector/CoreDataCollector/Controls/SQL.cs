﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Threading;
using CoreDataCollector.Models;
using CoreDataCollector.Models.DataSet;

namespace CoreDataCollector.Controls
{
    public enum JobState
    {
        Wait, Start, Complete, Cancel
    }

    public class SQLJob
    {
        public int ID = 0;
        public DateTime StartTime;
        public DateTime EndTime;
        public string MachineName;
        public string Status;
        public string ValueSetStart;
        public string ValueSetDone;
        public string RecorededBy;
        public JobState JobState;
    }

    public class SQL
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #region Properties
        //private QLMC_SQLDataContext _conn;
        private List<SQLJob> _jobStack;
        private System.Timers.Timer _execTimer;
        #endregion

        #region Constructors
        public SQL()
        {
            this._jobStack = new List<SQLJob>();
            this._execTimer = new System.Timers.Timer();
            this._execTimer.Elapsed += this.InsertJOb;
            this._execTimer.Interval = 5000;
            this._execTimer.Enabled = true;
        }
        #endregion

        #region Methods
        public void RecordToDB(Machine machine)
        {
            //string combinedData;//= machineName + "|" + data;
            if(machine.BatchInfo.Status == "PROCESSING")
            {
                string data = string.Empty;
                SQLJob newJob = new SQLJob();
                newJob.MachineName = machine.Name;
                newJob.StartTime = machine.BatchInfo.StartTime.Value;
                newJob.Status = machine.BatchInfo.Status;
                newJob.RecorededBy = "SYSTEM";
                newJob.JobState = JobState.Start;
                //Define data to save
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.ProductionName) + "\" Va=\"" + machine.BatchInfo.ProductionName.Value + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.RecipeID) + "\" Va=\"" + machine.BatchInfo.RecipeID.Value + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchOrder) + "\" Va=\"" + machine.BatchInfo.BatchOrder.ValueString + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchNumber) + "\" Va=\"" + machine.BatchInfo.BatchNumber.ValueString + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchTotal) + "\" Va=\"" + machine.BatchInfo.BatchTotal.ValueString + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.Line) + "\" Va=\"" + machine.BatchInfo.Line.ValueString + "\" />" + System.Environment.NewLine;
                foreach (DataPoint dp in machine.DataPoints)
                {
                    data += "<DataPoint DP = \"" + dp.Name + " " + nameof(dp.SetPoint) + "\" Va=\"" + dp.SetPoint.ValueString + "\" />" + System.Environment.NewLine;
                }

                newJob.ValueSetStart = "<ROOT>" + System.Environment.NewLine + data + "</ROOT>";
                this._jobStack.Add(newJob);
            }else
            {
                string data = string.Empty;

                SQLJob currentJob = this._jobStack.FirstOrDefault(x => x.MachineName == machine.Name);
                this._jobStack.Remove(currentJob);

                currentJob.EndTime = machine.BatchInfo.EndTime.Value;
                currentJob.Status = machine.BatchInfo.Status;

                if (machine.BatchInfo.Status == "COMPLETED")
                {
                    currentJob.JobState = JobState.Complete;
                    foreach (DataPoint dp in machine.DataPoints)
                    {
                        data += "<DataPoint DP = \"" + dp.Name + " " + nameof(dp.Actual) + "\" Va=\"" + dp.Actual.ValueString + "\" />" + System.Environment.NewLine;
                    }
                    currentJob.ValueSetDone = "<ROOT>" + System.Environment.NewLine + data + "</ROOT>";
                }
                if (machine.BatchInfo.Status == "CANCELED")
                {
                    currentJob.JobState = JobState.Cancel;
                }
                this._jobStack.Add(currentJob);
            }

            //Define data to save
            /*string data = "<ROOT>" + System.Environment.NewLine; //Open of xml            
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.ProductionName) + "\" Va=\"" + machine.BatchInfo.ProductionName.Value + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.ProductionID) + "\" Va=\"" + machine.BatchInfo.ProductionID.Value + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchOrder) + "\" Va=\"" + machine.BatchInfo.BatchOrder.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchNumber) + "\" Va=\"" + machine.BatchInfo.BatchNumber.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchTotal) + "\" Va=\"" + machine.BatchInfo.BatchTotal.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.Line) + "\" Va=\"" + machine.BatchInfo.Line.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.StartTime) + "\" Va=\"" + machine.BatchInfo.StartTime.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.EndTime) + "\" Va=\"" + machine.BatchInfo.EndTime.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.Status) + "\" Va=\"" + machine.BatchInfo.Status + "\" />" + System.Environment.NewLine;

            foreach (DataPoint dp in machine.DataPoints)
            {
                data += "<DataPoint DP = \"" + dp.Name + " " + nameof(dp.Actual) + "\" Va=\"" + dp.Actual.ValueString + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + dp.Name + " " + nameof(dp.SetPoint) + "\" Va=\"" + dp.SetPoint.ValueString + "\" />" + System.Environment.NewLine;
            }
            data += "</ROOT>";*/

            //this._jobStack.Add(combinedData);
            //Thread sqlThread = new Thread(new ParameterizedThreadStart(InsertJOb));
            //sqlThread.Start(combinedData);
            //sqlThread = null;            
        }

        private void InsertJOb(object source, ElapsedEventArgs e)
        {
            SQLJob job = this._jobStack.Where(x => x.JobState!= JobState.Wait).FirstOrDefault();
            if(job != null)
            {
                this._jobStack.Remove(job);
                if(job.JobState == JobState.Start)
                {
                    using (QLMC_SQLDataContext sql = new QLMC_SQLDataContext())
                    {
                        try
                        {
                            job.ID = sql.QLMC_Record_BatchStart(job.StartTime, job.MachineName, job.RecorededBy, job.ValueSetStart);
                            job.JobState = JobState.Wait;
                            this._jobStack.Add(job);
                            log.Debug("Data has been inserted to SQL for " + job.MachineName + ": \r\nStartTime: " + job.StartTime.ToString() + "\r\nMachineName: " + job.MachineName + "\r\nRecorded By:" + job.RecorededBy + "\r\nStatus: " + job.Status + "\r\n" + job.ValueSetStart);
                        }
                        catch(Exception ex)
                        {
                            this._jobStack.Add(job);
                            log.Debug("Failed to Insert data into SQL for " + job.MachineName + ". Cannot save data now. The service will try again\r\nError Meassage:" + ex.Message + "\r\nStartTime: " + job.StartTime.ToString() + "\r\nMachineName: " + job.MachineName + "\r\nRecorded By:" + job.RecorededBy + "\r\nStatus: " + job.Status);
                        }
                    }
                }
                else
                {
                    using (QLMC_SQLDataContext sql = new QLMC_SQLDataContext())
                    {
                        try
                        {
                            sql.QLMC_Record_BatchDone(job.ID, job.EndTime, job.Status, job.ValueSetDone);
                            log.Debug("Data has been inserted to SQL for " + job.MachineName + ": \r\nEndTime: " + job.EndTime.ToString() + "\r\nMachineName: " + job.MachineName + "\r\nRecorded By: " + job.RecorededBy + "\r\nStatus: " + job.Status + "\r\n" + job.ValueSetDone);
                            job = null;
                        }
                        catch(Exception ex)
                        {
                            this._jobStack.Add(job);
                            log.Debug("Failed to Insert data into SQL for " + job.MachineName + ". Cannot save data now. The service will try again\r\nError Meassage:" + ex.Message + "\r\nEndTime: " + job.EndTime.ToString() + "\r\nMachineName: " + job.MachineName + "\r\nRecorded By:" + job.RecorededBy + "\r\nStatus: " + job.Status);
                        }
                        
                    }
                }


                /*string[] theData = combinedString.Split('|');
                int id;
                using (QLMC_SQLDataContext sql = new QLMC_SQLDataContext())
                {
                    try
                    {
                        id = sql.QLMC_Record_stepA(DateTime.Now, theData[0]);
                        int insetedRows = sql.QLMC_Record_stepB(id, theData[1]);
                        if(insetedRows > 0)
                        {
                            this._jobStack.Remove(combinedString);
                            log.Debug("Data has been inserted to SQL for " + theData[0] + ": \r\n" + theData[1]);
                        }
                        else
                        {
                            log.Warn("Failed at Inserting data into SQL > StepB.\r\nCannot save data now. The service will try again in 5s");
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        log.Error("Failed at Inserting data into SQL > StepA.\r\nError: " + ex.Message + "\r\nCannot save data for :" + theData[0] + "\r\n" + theData[1]);
                    }


                    /*if (id == 0)
                    {

                        //Logger.Log(LogLevel.ERROR, DateTime.Now, "Failed at Inserting data into SQL > StepA");
                    }
                    else
                    {
                        //Logger.Log(LogLevel.DEBUG, DateTime.Now, "Date has been inserted to SQL: \r\n" + theData[1]);
                    }
                }*/
            }
                        
        }
        #endregion
    }
}
