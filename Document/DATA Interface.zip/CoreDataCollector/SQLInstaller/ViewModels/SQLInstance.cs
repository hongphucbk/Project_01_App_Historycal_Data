﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using SQLInstaller.Models;
using Microsoft.SqlServer.Management.Smo.Wmi;
using System.ComponentModel;

namespace SQLInstaller.ViewModels
{
    public class SQLInstance//: INotifyPropertyChanged
    {
        #region Properties
        private ObservableCollection<SQLInstanceModel> _sqlInstances;
        private string _selectedInstance;
        private bool _useNewInstance;
        private bool _useExistingInstance;
        private string _newInstanceName;
        private string _sqlAccount;
        private string _sqlPassword;
        #endregion

        #region Constructor
        public SQLInstance()
        {
            this._sqlInstances = new ObservableCollection<SQLInstanceModel>();
            List<string> instanceNames = this.Get_Instances_List();
            foreach(string item in instanceNames)
            {
                this._sqlInstances.Add(new SQLInstanceModel(item));
            }
            this._useExistingInstance = true;
        }
        #endregion

        #region Interfaces
        public ObservableCollection<SQLInstanceModel> SQLInstances
        {
            get { return this._sqlInstances; }
            set { this._sqlInstances = value; }
        }

        public string SelectedInstance {
            get { return this._selectedInstance; }
            set { this._selectedInstance = value;
                  //this.OnPropertyChanged("SelectedInstance");
            }
        }

        public string NewInstanceName
        {
            get { return this._newInstanceName; }
            set { this._newInstanceName = value;}
        }

        public string SqlAccount
        {
            get { return this._sqlAccount; }
            set { this._sqlAccount = value; }
        }

        public string SqlPassword
        {
            get { return this._sqlPassword; }
            set { this._sqlPassword = value; }
        }

        public bool UseExistingInstance
        {
            get { return this._useExistingInstance; }
            set { this._useExistingInstance = value;
                  this._useNewInstance = !value;
                  //this.OnPropertyChanged("UseExistingInstance");
            }
        }

        public bool UseNewInstance
        {
            get { return this._useNewInstance; }
            set { this._useNewInstance = value;
                  this._useExistingInstance = !value;
                  //this.OnPropertyChanged("UseNewInstance");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Methods
        /*private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }*/

        private List<string> Get_Instances_List()
        {
            List<string> list = new List<string>();

            ManagedComputer mc = new ManagedComputer(".");
            mc.ConnectionSettings.ProviderArchitecture = ProviderArchitecture.Use64bit;
            foreach (ServerInstance si in mc.ServerInstances)
            {
                list.Add(si.Name);
            }

            ManagedComputer mc32 = new ManagedComputer(".");
            mc.ConnectionSettings.ProviderArchitecture = ProviderArchitecture.Use32bit;
            foreach (ServerInstance si in mc32.ServerInstances)
            {
                list.Add(si.Name);
            }

            return list;
        }
        #endregion


    }
}
