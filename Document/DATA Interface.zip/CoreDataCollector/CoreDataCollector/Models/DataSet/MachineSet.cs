﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class MachineSet
    {
        #region Properties
        private Machine _machine;
        private string _name;
        private List<string> _dataPointNames;
        private string _plcName;
        #endregion

        #region Interfaces
        public Machine Machine { get { return this._machine; } set { this._machine = value; } }
        public string Name { get { return this._name; } set { this._name = value; } }
        public List<string> DataPointNames { get { return this._dataPointNames; } set { this._dataPointNames = value; } }
        public string PLCName { get { return this._plcName; } set { this._plcName = value; } }
        #endregion

        #region Constructors
        public MachineSet(string name, List<string> dataPointNames, string plcName)
        {
            //string error = string.Empty;
            //LogLevel level;
            this._name = name;
            this._dataPointNames = dataPointNames;
            this._plcName = plcName;
            //this._machine = new Machine(this._name, this._dataPointNames, ref plc,out error, out level);
            //Logger.Log(level, DateTime.Now, error);
        }
        #endregion
    }
}
