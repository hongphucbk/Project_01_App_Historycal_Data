﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class BatchInfo
    {
        #region  Properties
        private DataPairString _productionName;
        private DataPairString _recipeId;
        private DataPairInt _batchOrder;
        private DataPairInt _batchNumber;
        private DataPairInt _batchTotal;
        private DataPairInt _line;
        private DataPairDatetime _startTime;
        private DataPairDatetime _endTime;
        private string _status;
        #endregion

        #region Interfaces
        public DataPairString ProductionName { get { return _productionName; } set { this._productionName = value; } }
        public DataPairString RecipeID { get { return _recipeId; } set { this._recipeId = value; } }
        public DataPairInt BatchOrder { get { return _batchOrder; } set { this._batchOrder = value; } }
        public DataPairInt BatchNumber { get { return _batchNumber; } set { this._batchNumber = value; } }
        public DataPairInt BatchTotal { get { return _batchTotal; } set { this._batchTotal = value; } }
        public DataPairInt Line { get { return _line; } set { this._line = value; } }
        public DataPairDatetime StartTime { get { return this._startTime; } set { this._startTime = value; } }
        public DataPairDatetime EndTime { get { return this._endTime; } set { this._endTime = value; } }
        public string Status { get { return this._status; } set { this._status = value; } }
        #endregion

        #region Constructors
        /// <summary>
        /// By default, ProductionName and Id are empty. Batch Order, Number, Total and Line are zero
        /// </summary>
        public BatchInfo()
        {
            this._productionName = new DataPairString();
            this._recipeId = new DataPairString();
            this._batchOrder = new DataPairInt();
            this._batchNumber = new DataPairInt();
            this._batchTotal = new DataPairInt();
            this._line = new DataPairInt();
            this._startTime = new DataPairDatetime();
            this._endTime = new DataPairDatetime();
        }
        #endregion
    }
}
