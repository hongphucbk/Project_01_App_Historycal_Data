﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using CoreDataCollector.Models;
using CoreDataCollector.Models.DataSet;

namespace CoreDataCollector.Controls
{
    public class Monitor
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #region Properties
        //public PLC Plc;
        public List<PLC> PLCList;
        public List<MachineSet> MachineSets;
        private Timer _timerCheckSignal;
        private Timer _timerHeartBeat;
        private int _intervalCheckSignal;
        private int _intervalHeartBeat;
        private SQL _cur2SQL;
        #endregion

        #region Interfaces
        //public PLC PLC { get { return this._plc; } set { this._plc = value; } }
        //public List<MachineSet> MachineSets { get { return this._machineSets; } set { this._machineSets = value; } }
        #endregion

        #region Constructors
        public Monitor(int timerInterval, ref SQL sql)
        {
            this._intervalCheckSignal = timerInterval;
            this._intervalHeartBeat = 600000;
            this._cur2SQL = sql;
            //this.Plc = new PLC();
            //this.PLCList = new List<PLC>() { };
            //this.MachineSets = new List<MachineSet> { };
            this.InitializeTimer();
        }
        #endregion

        #region Methods
        private void InitializeTimer()
        {
            //Setup CheckSignal Timer
            this._timerCheckSignal = new Timer();
            this._timerCheckSignal.Elapsed += CheckPLCSignal;
            this._timerCheckSignal.Interval = this._intervalCheckSignal;
            //this._timerCheckSignal.Enabled = false;
            GC.KeepAlive(this._timerCheckSignal);

            //Setup HeartBeat Timer
            this._timerHeartBeat = new Timer();
            this._timerHeartBeat.Elapsed += CheckHeartBeat;
            this._timerHeartBeat.Interval = this._intervalHeartBeat;
            //this._timerHeartBeat.Enabled = true;
            GC.KeepAlive(this._timerHeartBeat);
        }

        public void Start()
        {
            this._timerCheckSignal.Enabled = true;
            this._timerHeartBeat.Enabled = true;
        }

        public void Stop()
        {
            this._timerCheckSignal.Enabled = false;
            this._timerHeartBeat.Enabled = false;
        }

        private void CheckPLCSignal(object source, ElapsedEventArgs e)
        {
            foreach(MachineSet item in this.MachineSets)
            {
                //Detect the rising edge happens with the bit
                bool previousStart = item.Machine.ControlSignal.Start.Value;
                bool previousStop = item.Machine.ControlSignal.Stop.Value;
                bool previousCompleted = item.Machine.ControlSignal.Completed.Value;
                item.Machine.UpdateControlSignal();
                bool startNewBatch = (item.Machine.ControlSignal.Start.Value ==true) & (previousStart == false);
                bool cancelBatch = (item.Machine.ControlSignal.Stop.Value == true) & (previousStop == false);
                bool completeBatch = (item.Machine.ControlSignal.Completed.Value == true) & (previousCompleted == false);
                if (startNewBatch)
                {
                    //Read all value and call SQL object here
                    log.Debug("Batch start in "+item.Name);
                    //Console.WriteLine("Rising Edge happens at {0}", item.Name);
                    item.Machine.ReadBatchData();
                    this._cur2SQL.RecordToDB(item.Machine);
                }
                if (completeBatch)
                {
                    log.Debug("Batch completes in " + item.Name);
                    item.Machine.ReadBatchComplete();
                    this._cur2SQL.RecordToDB(item.Machine);
                }
                if (cancelBatch)
                {
                    log.Debug("Batch canceled in " + item.Name);
                    item.Machine.ReadBatchCancel();
                    this._cur2SQL.RecordToDB(item.Machine);
                }

                //Save value
                //item.Machine.ControlSignal.Completed.Value = result;
            }
        }

        private void CheckHeartBeat(object source, ElapsedEventArgs e)
        {
            foreach(PLC plc in this.PLCList)
            {
                if (plc.Connected())
                {
                    log.Info("Heartbeat PLC " + plc.Name + " is alive. IP: " + plc.IP.ToString() + " Rack: " + plc.Rack.ToString() + " Slot: " + plc.Slot.ToString());
                }
                else
                {
                    log.Error("Heartbeat PLC " + plc.Name + " is disconnected. IP: " + plc.IP.ToString() + " Rack: " + plc.Rack.ToString() + " Slot: " + plc.Slot.ToString());
                    log.Info("Heartbeat Trying to connect...");
                    plc.PLCConnect();
                    
                }
            }
        }

        /*private void SaveData2SQL(Machine machine)
        {
            //Define data to save
            string data = "<ROOT>" + System.Environment.NewLine; //Open of xml            
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.ProductionName) + "\" Va=\"" + machine.BatchInfo.ProductionName.Value+ "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.ProductionID) + "\" Va=\"" + machine.BatchInfo.ProductionID.Value + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchOrder) + "\" Va=\"" + machine.BatchInfo.BatchOrder.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchNumber) + "\" Va=\"" + machine.BatchInfo.BatchNumber.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.BatchTotal) + "\" Va=\"" + machine.BatchInfo.BatchTotal.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.Line) + "\" Va=\"" + machine.BatchInfo.Line.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.StartTime) + "\" Va=\"" + machine.BatchInfo.StartTime.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.EndTime) + "\" Va=\"" + machine.BatchInfo.EndTime.ValueString + "\" />" + System.Environment.NewLine;
            data += "<DataPoint DP = \"" + nameof(machine.BatchInfo.Status) + "\" Va=\"" + machine.BatchInfo.Status + "\" />" + System.Environment.NewLine;

            foreach (DataPoint dp in machine.DataPoints)
            {
                data += "<DataPoint DP = \"" + dp.Name + " "+nameof(dp.Actual) + "\" Va=\"" + dp.Actual.ValueString + "\" />" + System.Environment.NewLine;
                data += "<DataPoint DP = \"" + dp.Name + " " + nameof(dp.SetPoint) + "\" Va=\"" + dp.SetPoint.ValueString + "\" />" + System.Environment.NewLine;
            }
            data += "</ROOT>";
            this._cur2SQL.RecordToDB(machine.Name, data);
        }*/
        #endregion
    }
}
