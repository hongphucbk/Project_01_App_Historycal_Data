﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models
{
    public enum LogLevel
    {
        ALL, DEBUG, INFO, WARN, ERROR, FATAL
    }

    public static class Logger
    {
        #region Properties

        #endregion
        public static void Log(LogLevel level, DateTime time, string message)
        {
            Console.WriteLine(time.ToString("dd/MM/yyyy HH:mm:ss.ffff") + "," + level.ToString() + "," + message);
        }
        #region Methods
        #endregion
    }
}
