﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreDataCollector.Controls;
using CoreDataCollector.Models;
using Topshelf;

namespace CoreDataCollector
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {
            var rc = HostFactory.Run(x =>                                   //1
            {
                x.Service<Controls.Host>(s =>                                   //2
                {
                    s.ConstructUsing(name => new Controls.Host());                //3
                    s.WhenStarted(tc => tc.Start());                         //4
                    s.WhenStopped(tc => tc.Stop());                          //5
                });
                x.RunAsLocalSystem();                                       //6

                x.SetDescription("Capture data from Siemens PLC and store them in MSSQL database");                   //7
                x.SetDisplayName("CoreDataCollector");                                  //8
                x.SetServiceName("CoreDataCollector");                                  //9
            });                                                             //10

            var exitCode = (int)Convert.ChangeType(rc, rc.GetTypeCode());  //11
            Environment.ExitCode = exitCode;
        }
    }
}
