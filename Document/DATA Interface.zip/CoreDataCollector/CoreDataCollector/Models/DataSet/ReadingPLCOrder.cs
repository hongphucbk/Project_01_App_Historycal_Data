﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class ReadingPLCOrder
    {
        #region Properties
        public string PLCName;
        public int StartByte;
        public int EndByte;
        #endregion
    }
}
