﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class PLCAddress
    {
        #region Properties
        private int _db;
        private string _type;
        private int _adr;
        private int _bit;
        #endregion

        #region Interface
        public int DB { get { return this._db; } set { this._db = value; } }
        public string Type { get { return this._type; } set { this._type = value; } }
        public int Adr { get { return this._adr; } set { this._adr = value; } }
        public int Bit { get { return this._bit; } set { this._bit = value; } }
        #endregion

        #region Construction
        public PLCAddress(string address)
        {
            string[] temp = address.Split('.');
            if(temp.Count() > 1)
            {
                this._db = Convert.ToInt32(temp[0].Remove(0, 2));
                this._type = temp[1].Substring(0, 3);
                this._adr = Convert.ToInt32(temp[1].Substring(3));
                if(this._type == "DBX")
                {
                    this._bit = Convert.ToInt32(temp[2]);
                }
            }
        }
        #endregion

        #region Methods
        public static void GetInfo(List<PLCAddress> listPLCAdr, out int start, out int size)
        {
            List<PLCAddress> orderedList = listPLCAdr.OrderBy(e => e.Adr).ToList();
            PLCAddress first = orderedList.FirstOrDefault();
            start = first.Adr;

            PLCAddress last = orderedList.LastOrDefault();
            switch (last.Type)
            {
                case "DBX":
                    size = last.Adr - first.Adr + 1;
                    break;
                case "DBB":
                    size = last.Adr - first.Adr + 1;
                    break;
                case "DBW":
                    size = last.Adr - first.Adr + 2;
                    break;
                case "DBD":
                    size = last.Adr - first.Adr + 2;
                    break;
                default:
                    size = last.Adr - first.Adr + 1;
                    break;
            }
        }
        #endregion
    }
}
