﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class DataPoint
    {
        #region Properties
        private string _name;
        private DataPairFloat _setpoint;
        private DataPairFloat _actual;
        #endregion

        #region Interfaces
        public string Name { get { return _name; } set { _name = value; } }
        public DataPairFloat SetPoint { get { return _setpoint; } set { _setpoint = value; } }
        public DataPairFloat Actual { get { return _actual; } set { _actual = value; } }
        #endregion

        #region Constructors
        /// <summary>
        /// By default, Name is empty, Setpoint=0, Actual=0
        /// </summary>
        public DataPoint()
        {
            this._name = string.Empty;
            this._setpoint = new DataPairFloat();
            this._actual = new DataPairFloat();
        }
        public DataPoint(string name)
        {
            this._name = name;
            this._setpoint = new DataPairFloat();
            this._actual = new DataPairFloat();
        }
        #endregion
    }
}
