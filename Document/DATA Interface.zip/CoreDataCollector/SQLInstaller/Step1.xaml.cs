﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.SqlServer.Management.Smo.Wmi;
using SQLInstaller.ViewModels;

namespace SQLInstaller
{
    /// <summary>
    /// Interaction logic for Core_Data_Collector_Installation.xaml
    /// </summary>
    public partial class Core_Data_Collector_Installation : Window
    {
        #region Properties
        private SQLInstance instances;
        #endregion

        #region Constructors
        public Core_Data_Collector_Installation()
        {
            InitializeComponent();
            instances = new SQLInstance();
        }
        #endregion

        #region Methods

        #endregion

        #region Events
        private void Btn_Install_Click(object sender, RoutedEventArgs e)
        {
            
        }
        #endregion

        private void Btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
