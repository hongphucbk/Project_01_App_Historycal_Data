﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class ControlSignal
    {
        #region Properties
        private DataPairBool _start;
        private DataPairBool _stop;
        private DataPairBool _completed;
        #endregion

        #region Interfaces
        public DataPairBool Start { get { return _start; } set { this._start = value; } }
        public DataPairBool Stop { get { return _stop; } set { this._stop = value; } }
        public DataPairBool Completed { get { return _completed; } set { this._completed = value; } }
        #endregion

        #region Constructors
        /// <summary>
        /// By default, Start=False Stop=True Completed=False
        /// </summary>
        public ControlSignal()
        {
            this._start = new DataPairBool(false, string.Empty);
            this._stop = new DataPairBool(true, string.Empty);
            this._completed = new DataPairBool(false, string.Empty);
        }
        #endregion
    }
}
