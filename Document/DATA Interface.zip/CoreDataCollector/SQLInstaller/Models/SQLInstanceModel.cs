﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLInstaller.Models
{
    public class SQLInstanceModel// : INotifyPropertyChanged
    {
        #region Properties
        private string _instanceName;
        #endregion

        #region Interfaces
        public string InstanceName    {   get {   return this._instanceName; }
            set { this._instanceName = value; }}
        #endregion

        #region Constructors
        public SQLInstanceModel(string instanceName)
        {
            this._instanceName = instanceName;
        }
        #endregion

        #region Methods
        /*private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }*/
        #endregion

        #region Events
        //public event PropertyChangedEventHandler PropertyChanged;
        #endregion
    }
}
