﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models.DataSet
{
    public class Machine
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #region Properties
        private string _name;
        private int _sqlID;
        private BatchInfo _batchInfo;
        private ControlSignal _controlSignal;
        private List<DataPoint> _dataPoints;
        private List<string> _dataPointsName;
        private PLC _plc;
        private int _DBnumber;
        private int _start;
        private int _size;
        #endregion

        #region Interfaces
        public string Name { get { return _name; } set { this._name = value; } }
        public int SQLid { get { return _sqlID; } set { this._sqlID = value; } }
        public BatchInfo BatchInfo { get { return _batchInfo; } set { this._batchInfo = value; } }
        public ControlSignal ControlSignal { get { return _controlSignal; } set { this._controlSignal = value; } }
        public List<DataPoint> DataPoints { get { return _dataPoints; } set { this._dataPoints = value; } }
        public PLC PLC { get { return this._plc; } set { this._plc = value; } }
        #endregion

        #region Constructors
        /// <summary>
        /// Initialize the Object
        /// </summary>
        /// <param name="name">Machine name</param>
        /// <param name="dataPointName">List of DataPoint Names</param>
        /// <param name="error"></param>
        /// <param name="level"></param>
        public Machine(string name, List<string> dataPointName, ref PLC plc, out bool success)
        {
            //level = LogLevel.DEBUG;
            this._name = name;
            this._batchInfo = new BatchInfo();
            this._controlSignal = new ControlSignal();
            this._dataPoints = new List<DataPoint>();
            this._dataPointsName = dataPointName;
            this._plc = plc;

            this.InitDataPoints();
            success = this.LoadAddress();

            if (success)
            {
                this.AnalyzeAddress();
            }

            /*if(level == LogLevel.ERROR)
            {
                error = "Cannot create \"" + name+"\"";
            }
            else
            {
                error = "Create \"" + name + "\" successfully";
            }*/                        
        }
        #endregion

        #region Methods
        /// <summary>
        /// Create DataPoints
        /// </summary>
        private void InitDataPoints()
        {
            foreach(string item in this._dataPointsName)
            {
                this._dataPoints.Add(new DataPoint(item));
            }
        }

        /// <summary>
        /// Load PLC Addresses from App.config
        /// </summary>
        /// <param name="totallevel"></param>
        private bool LoadAddress()
        {
            bool finalsuccess = true;
            bool success = true;
            //totallevel = LogLevel.DEBUG;
            //string error = string.Empty;
            //LogLevel level = LogLevel.DEBUG;
            //Load Control Signal
            this._controlSignal.Start.Address = Config.GetValue(this._name + "." + nameof(this._controlSignal.Start), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._controlSignal.Stop.Address = Config.GetValue(this._name + "." + nameof(this._controlSignal.Stop), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._controlSignal.Completed.Address = Config.GetValue(this._name + "." + nameof(this._controlSignal.Completed), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            //Load BatchInfo Addresses
            this._batchInfo.ProductionName.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.ProductionName), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._batchInfo.RecipeID.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.RecipeID), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._batchInfo.BatchOrder.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.BatchOrder), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._batchInfo.BatchNumber.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.BatchNumber), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._batchInfo.BatchTotal.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.BatchTotal), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            this._batchInfo.Line.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.Line), out success);
            finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            //this._batchInfo.StartTime.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.StartTime), out success);
            //finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            //this._batchInfo.EndTime.Address = Config.GetValue(this._name + "." + nameof(this._batchInfo.EndTime), out success);
            //finalsuccess = finalsuccess & success;
            //if (level == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            //Logger.Log(level, DateTime.Now, error);
            //Load DataPoints Addresses
            foreach (DataPoint item in this._dataPoints)
            {
                //string ierror = string.Empty;
                //LogLevel ilevel;
                item.Actual.Address = Config.GetValue( this._name + "." + item.Name + ".ACTUAL", out success);
                finalsuccess = finalsuccess & success;
                //Logger.Log(ilevel, DateTime.Now, ierror);

                item.SetPoint.Address = Config.GetValue(this._name + "." + item.Name + ".SETPOINT", out success);
                finalsuccess = finalsuccess & success;
                //Logger.Log(ilevel, DateTime.Now, ierror);
                //if (ilevel == LogLevel.ERROR) { totallevel = LogLevel.ERROR; }
            }
            return finalsuccess;
        }

        public void AnalyzeAddress()
        {
            bool consistency = true;

            List<PLCAddress> plcAdr = new List<PLCAddress>();

            plcAdr.Add(new PLCAddress(this._controlSignal.Start.Address));
            plcAdr.Add(new PLCAddress(this._controlSignal.Stop.Address));
            plcAdr.Add(new PLCAddress(this._controlSignal.Completed.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.ProductionName.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.RecipeID.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.BatchOrder.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.BatchNumber.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.BatchTotal.Address));
            plcAdr.Add(new PLCAddress(this._batchInfo.Line.Address));

            foreach (DataPoint item in this._dataPoints)
            {
                plcAdr.Add(new PLCAddress(item.Actual.Address));
                plcAdr.Add(new PLCAddress(item.SetPoint.Address));
            }

            //Check if all variables in the same DB
            int tempDB = plcAdr.FirstOrDefault().DB;
            foreach(PLCAddress pa in plcAdr)
            {
                if(pa.DB != tempDB)
                {
                    consistency = false;
                }
            }

            if (consistency)
            {
                this._DBnumber = tempDB;
                PLCAddress.GetInfo(plcAdr, out this._start, out this._size);
                log.Debug("Data range detected. DB" + this._DBnumber.ToString()+ " Start from Byte " + this._start.ToString() + " contains " + this._size.ToString() + " bytes");
            }
            else
            {
                log.Error("All variables must be in the same DB, please correct");
            }            
        }

        public void UpdateControlSignal()
        {
            string adr = this.ControlSignal.Start.Address;
            this.ControlSignal.Start.Value = this._plc.ReadBit(adr);

            adr = this.ControlSignal.Stop.Address;
            this.ControlSignal.Stop.Value = this._plc.ReadBit(adr);

            adr = this.ControlSignal.Completed.Address;
            this.ControlSignal.Completed.Value = this._plc.ReadBit(adr);
           
        }

        public void ReadBatchData()
        {
            this._batchInfo.ProductionName.Value = this._plc.ReadString(this._batchInfo.ProductionName.Address);
            this._batchInfo.RecipeID.Value = this._plc.ReadString(this._batchInfo.RecipeID.Address);
            this._batchInfo.BatchNumber.Value = this._plc.ReadInteger(this._batchInfo.BatchNumber.Address);
            this._batchInfo.BatchOrder.Value = this._plc.ReadInteger(this._batchInfo.BatchOrder.Address);
            this._batchInfo.BatchTotal.Value = this._plc.ReadDInteger(this._batchInfo.BatchTotal.Address);
            this._batchInfo.Line.Value = this._plc.ReadInteger(this._batchInfo.Line.Address);
            this._batchInfo.StartTime.Value = DateTime.Now;
            this._batchInfo.Status = "PROCESSING";
            //this._batchInfo.EndTime.Value = this._plc.ReadDateTime(this._batchInfo.EndTime.Address);

            foreach (DataPoint dp in this._dataPoints)
            {
                dp.SetPoint.Value = this._plc.ReadReal(dp.SetPoint.Address);
            }

        }

        public void ReadBatchComplete()
        {
            this._batchInfo.EndTime.Value = DateTime.Now;
            this._batchInfo.Status = "COMPLETED";
            foreach (DataPoint dp in this._dataPoints)
            {
                dp.Actual.Value = this._plc.ReadReal(dp.Actual.Address);
            }
        }

        public void ReadBatchCancel()
        {
            this._batchInfo.EndTime.Value = DateTime.Now;
            this._batchInfo.Status = "CANCELED";
            /*foreach (DataPoint dp in this._dataPoints)
            {
                dp.Actual.Value = this._plc.ReadReal(dp.Actual.Address);
            }*/
        }
        #endregion
    }
}
