﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreDataCollector.Models;
using CoreDataCollector.Models.DataSet;

namespace CoreDataCollector.Controls
{
    /// <summary>
    /// This object helps to Initilize the Application
    /// </summary>
    public class Init
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Constructors
        /// <summary>
        /// Load all parameters from App.config and Connect to PLC
        /// </summary>
        public Init(ref ConnectionStringSettings sqlConnection, ref List<PLC> plcList, ref List<MachineSet> machinesets, out bool success)
        {
            bool asign = true;
            bool plcready = true;
            //Asign objects
            /*this._sql = sqlConnection;
            this._plc = plc;
            this._machinesets = machinesets;*/
            //Start Initialization
            log.Info("Start Initilization");
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Start Initilization");
            //Initilize Data Objects
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Start Data Objects Initialization");
            //result = this.InitializeDataObjects(ref machinesets) && result;
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Finish Data Objects Initialization");
            //Load paramters in App.config
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Start loading paramters from App.config");
            //result &= this.LoadParameters(ref sqlConnection, ref plcList) && result;
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Finish loading paramters from App.config");
            //Asign PLC to MachineSets
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Start to asign PLC to MachineSets");
            log.Info("Start to load PLC address from Configuration file");
            this.LoadPLCAddress(ref plcList);
            log.Info("Start to asign PLC to MachineSets");
            asign = this.AssignPLC2Machine(ref plcList, ref machinesets);
            log.Info("Finish to asign PLC to MachineSets");
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Finish to asign PLC to MachineSets");
            //Connect to PLC
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Start to connect to PLCs");
            log.Info("Start to connect to PLCs");
            plcready = this.PLCready(ref plcList) && asign;
            if (plcready)
            {
                log.Debug("All PLCs are connected");
            }
            else
            {
                log.Warn("Some of PLCs are not connected. The system will try to re-connect after 10mins. Check your physical connections or your PLC's IP to correct them in Configuration file and restart the Service");
            }
            log.Info("Finish to connect to PLCs");
            //Logger.Log(LogLevel.INFO, DateTime.Now, "Finish to connect to PLCs");
            success = asign;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Load paramters from App.config
        /// </summary>
        /*private bool LoadParameters(ref ConnectionStringSettings sql, ref List<PLC> plcList)
        {
            string error = string.Empty;
            LogLevel level;
            bool success = true;

            sql = Config.GetSQLConnString("SQLDB",out error, out level);
            if (level == LogLevel.ERROR) { success = false; }
            Logger.Log(level, DateTime.Now, error);

            foreach(PLC plc in plcList)
            {
                plc.IP = Config.GetValue(plc.Name+".IP", out error, out level);
                if (level == LogLevel.ERROR) { success = false; }
                Logger.Log(level, DateTime.Now, error);

                plc.Rack = Int32.Parse(Config.GetValue(plc.Name+".Rack", out error, out level));
                if (level == LogLevel.ERROR) { success = false; }
                Logger.Log(level, DateTime.Now, error);

                plc.Slot = Int32.Parse(Config.GetValue(plc.Name+".Slot", out error, out level));
                if (level == LogLevel.ERROR) { success = false; }
                Logger.Log(level, DateTime.Now, error);
            }            

            return success;
        }*/

        /// <summary>
        /// Create Data models
        /// </summary>
        /*private bool InitializeDataObjects(ref List<MachineSet> machinesets)
        {
            string error = string.Empty;
            LogLevel level;
            bool success = true;
            //Create Machines
            foreach(MachineSet item in machinesets)
            {
                item.Machine = new Machine(item.Name, item.DataPointNames, out error, out level);
                Logger.Log(level, DateTime.Now, error);
                if (level == LogLevel.ERROR) { success = false; }
            }
            return success;
        }*/


        private bool LoadPLCAddress(ref List<PLC> plcList)
        {
            bool finalsuccess = true;
            bool success = true;

            foreach(PLC p in plcList)
            {
                p.IP = Config.GetValue(p.Name + ".IP", out success);
                finalsuccess = finalsuccess & success;
                string temp = Config.GetValue(p.Name + ".Rack", out success);
                p.Rack = Convert.ToInt32(temp);
                finalsuccess = finalsuccess & success;
                temp = Config.GetValue(p.Name + ".Slot", out success);
                p.Slot = Convert.ToInt32(temp);
                finalsuccess = finalsuccess & success;
            }

            return finalsuccess;
        }

        private bool AssignPLC2Machine(ref List<PLC> plcList, ref List<MachineSet> machineSets)
        {
            //string err;
            //LogLevel level = LogLevel.DEBUG;
            bool success = true;
            foreach(MachineSet machineset in machineSets)
            {
                PLC p;

                p = plcList.FirstOrDefault(plc => plc.Name == machineset.PLCName);
                if(p!= null)
                {
                    machineset.Machine = new Machine(machineset.Name, machineset.DataPointNames, ref p, out success);
                    log.Debug("Successfully Asign PLC " + machineset.PLCName + " to Machine " + machineset.Name);
                    //Logger.Log(LogLevel.DEBUG, DateTime.Now, "Successfully Asign PLC " + machineset.PLCName + " to Machine " + machineset.Name);
                }
                else
                {
                    //err = "Cannot find the PLC " + machineset.PLCName + " in \"PLCList\"";
                    //level = LogLevel.ERROR;
                    success = false;
                    log.Debug("Failed to Asign PLC " + machineset.PLCName + " to Machine " + machineset.Name + ". Contact the developer");
                    //Logger.Log(LogLevel.ERROR, DateTime.Now, "Failed to Asign PLC " + machineset.PLCName + " to Machine " + machineset.Name + ". Contact the developer");
                }                                
                
            }
            return success;
        }

        /// <summary>
        /// Connect to the PLC with defined paramters in App.config
        /// </summary>
        private bool PLCready(ref List<PLC> plcList)
        {
            //string error = string.Empty;
            //LogLevel level;
            bool success = true;

            //plc = new PLC(plc.IP, plc.Rack, plc.Slot);
            foreach(PLC plc in plcList)
            {
                success &= plc.PLCConnect();
                //if (level == LogLevel.ERROR) { success = false; }
                //Logger.Log(level, DateTime.Now, error + "," + plc.Name +" IP:" + plc.IP + " Rack:" + plc.Rack.ToString() + " Slot:" + plc.Slot.ToString());
            }
            

            //Test
            //string error;
            //LogLevel level;
            //bool result = false;

            //MachineSet mcs = this.MachineSets.Where(i => i.Name == "MACRO DOSING").FirstOrDefault();
            //string adr = mcs.Machine.ControlSignal.Start.Address;
            //result = plc.ReadBit("DB2.DBX0.0", out error, out level);
            //Console.WriteLine("Checked: " + result.ToString());
            //End Test

            return success;
        }

        #endregion
    }
}
