﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using CoreDataCollector.Models;
using CoreDataCollector.Models.DataSet;

namespace CoreDataCollector.Controls
{
    public class Host
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Properties
        private ConnectionStringSettings _sqlConn;
        private List<string> _macroDataPnames;
        private List<string> _microDataPnames;
        private List<string> _coaterDataPnames;

        private Init _init;
        private Monitor _monitor;
        private SQL _sql;
        #endregion

        #region Constructors
        public Host()
        {
            this.BuildHost();
            //this.Start();
        }
        #endregion

        #region Methods
        private void BuildHost()
        {
            //Define objects to be created
            //Data Points to be created
            this._macroDataPnames = new List<string>() { "BIN04"  , "BIN05"  , "BIN06",
                                                         "BIN07"  , "BIN08"  , "BIN09",
                                                         "BIN10"  , "BIN11"  , "BIN12",
                                                         "BIN13"  , "BIN14"  , "BIN15",
                                                         "BIN16"  , "BIN17"  , "BIN18",
                                                         "BIN19"  , "BIN20"  , "BIN21",
                                                         "BIN21"  , "BIN22"  , "BIN23",
                                                         "BIN24"  , "BIN25"  , "BIN26",
                                                         "BIN27"  , "BIN28"  , "BIN29",
                                                         "PM1A"   , "PM1A-1" , "PM1A-2"};
            this._microDataPnames = new List<string>() { "FishOil", "SoyOil" , "Lecitine",
                                                         "Water"  , "Presam" , "NA",
                                                         "PM1"    , "PM2"};
            this._coaterDataPnames = new List<string>() { "Meal", "Oil" };
            //Create SQL controller
            this._sql = new SQL();
            //Create Monitor
            this._monitor = new Monitor(250, ref this._sql);
            //PLC hosts
            this._monitor.PLCList = new List<PLC>() { new PLC("MainS7300") };
            //Machines to be created
            this._monitor.MachineSets = new List<MachineSet>() { new MachineSet("MACRO DOSING", this._macroDataPnames, "MainS7300"),
                                                                 new MachineSet("MICRO 1", this._microDataPnames,"MainS7300"),
                                                                 new MachineSet("MICRO 2", this._microDataPnames,"MainS7300"),
                                                                 new MachineSet("COATER CR", this._coaterDataPnames,"MainS7300"),
                                                                 new MachineSet("COATER PEL", this._coaterDataPnames,"MainS7300")};

        }

        public void Start()
        {
            //string error;
            //LogLevel level;
            bool success;
            log.Info("Start Host...");
            //Initialize objects
            this._init = new Init(ref this._sqlConn, ref this._monitor.PLCList, ref this._monitor.MachineSets, out success);
            //this._init.PropertyChanged += new PropertyChangedEventHandler(this.PropertyChanged);
            //Initialize Monitor
            /*if (success) {
            this._init = new Init(ref this._sqlConn, ref this._monitor.Plc, ref this._monitor.MachineSets, out success);
                this._monitor = new Monitor(250);
            }
            else
            {
                Logger.Log(LogLevel.INFO, DateTime.Now, "Canot Initialize the Application. The process cannot start");
            }*/
            if (success)
            {
                this._monitor.Start();
                log.Info("Initilization completes succesfully");
            }
            else
            {
                log.Error("Initilization completes with failure. The process of monitoring PLC will not start");
            }            
        }

        public void Stop()
        {
            log.Info("Stop Host...! Data has been recorded still being inserted into SQL");
            this._monitor.Stop();
        }
        #endregion
    }
}
