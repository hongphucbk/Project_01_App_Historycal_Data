﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataCollector.Models
{
    static public class Config
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Methods        

        /// <summary>
        /// A private interface to get data from App.config
        /// </summary>
        /// <param name="key">The keyword in App.config</param>
        /// <param name="error">Error message</param>
        /// <param name="level">Level of error</param>
        /// <returns></returns>
        static public string GetValue (string key, out bool success)
        {
            string value = string.Empty;
            value = ConfigurationManager.AppSettings[key];
            if (value == null)
            {
                //error = "Load \"" + key + "\" failed. The value does not exist. Check App.config";
                //level = LogLevel.ERROR;
                success = false;
                log.Error("Load \"" + key + "\" failed. The value does not exist. Check App.config");
            }
            else
            {
                //error = "Load \"" + key + "\" completed,"+value;
                //level = LogLevel.DEBUG;
                success = true;
                log.Debug("Load \"" + key + "\" completed," + value);
            }
            
            return value;
        }

        /// <summary>
        /// A private interface to get data from App.config
        /// </summary>
        /// <param name="key">The keyword in App.config</param>
        /// <param name="error">Error message</param>
        /// <param name="level">Level of error</param>
        /// <returns></returns>
        static public ConnectionStringSettings GetSQLConnString(string key, out string error, out LogLevel level)
        {
            ConnectionStringSettings sqlconn;
            sqlconn = ConfigurationManager.ConnectionStrings["SQLDB"];
            if (sqlconn == null)
            {
                error = "Load " + key + " failed. The value does not exist. Check App.config";
                level = LogLevel.ERROR;
            }
            else
            {
                error = "Load " + key + " completed";
                level = LogLevel.DEBUG;
            }
            return sqlconn;
        }
        #endregion
    }
}
